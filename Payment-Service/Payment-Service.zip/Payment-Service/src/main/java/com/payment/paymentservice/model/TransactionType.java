package com.payment.paymentservice.model;

public enum TransactionType 
{
	DEBIT, CREDIT
}
